const { MongoClient } = require('mongodb');

async function run() {
  const uri = "mongodb://localhost:27017"; // change if using Atlas
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const db = client.db('plp_bookstore');
    const books = db.collection('books');

    // Sample book documents
    const bookDocs = [
      {
        title: "The Art of Testing",
        author: "Jane Smith",
        genre: "Technology",
        published_year: 2018,
        price: 25,
        in_stock: true,
        pages: 320,
        publisher: "TechBooks"
      },
      {
        title: "Mystery of the Blue Moon",
        author: "John Doe",
        genre: "Mystery",
        published_year: 2015,
        price: 15,
        in_stock: false,
        pages: 210,
        publisher: "Story Press"
      },
      {
        title: "Adventures in Cooking",
        author: "Emily Johnson",
        genre: "Cooking",
        published_year: 2020,
        price: 30,
        in_stock: true,
        pages: 150,
        publisher: "Yummy Reads"
      },
      {
        title: "History of Ancient Civilizations",
        author: "Michael Brown",
        genre: "History",
        published_year: 2012,
        price: 20,
        in_stock: true,
        pages: 400,
        publisher: "History House"
      },
      {
        title: "Learning JavaScript",
        author: "Chris Lee",
        genre: "Technology",
        published_year: 2019,
        price: 40,
        in_stock: true,
        pages: 350,
        publisher: "CodePress"
      },
      {
        title: "The Great Outdoors",
        author: "Sarah Miller",
        genre: "Travel",
        published_year: 2017,
        price: 22,
        in_stock: false,
        pages: 280,
        publisher: "Wanderlust"
      },
      {
        title: "Romance in Paris",
        author: "Anna Wilson",
        genre: "Romance",
        published_year: 2021,
        price: 18,
        in_stock: true,
        pages: 200,
        publisher: "LoveBooks"
      },
      {
        title: "Mastering Photography",
        author: "David Clark",
        genre: "Art",
        published_year: 2016,
        price: 35,
        in_stock: true,
        pages: 300,
        publisher: "Creative Minds"
      },
      {
        title: "Gardening Basics",
        author: "Laura Davis",
        genre: "Hobby",
        published_year: 2014,
        price: 12,
        in_stock: true,
        pages: 180,
        publisher: "Green Thumb"
      },
      {
        title: "The Science of Space",
        author: "Robert King",
        genre: "Science",
        published_year: 2022,
        price: 28,
        in_stock: true,
        pages: 320,
        publisher: "Cosmos Publishing"
      }
    ];

    const result = await books.insertMany(bookDocs);
    console.log(`Inserted ${result.insertedCount} books.`);
  } catch (err) {
    console.error(err);
  } finally {
    await client.close();
  }
}

run();
