// Find all books in the "Science Fiction" genre
db.books.find({ genre: "Science Fiction" }).toArray();

// Find books published after 2015
db.books.find({ published_year: { $gt: 2015 } }).toArray();

// Update price of a specific book
db.books.updateOne({ title: "Book Title" }, { $set: { price: 19.99 } });

// Delete a book by title
db.books.deleteOne({ title: "Old Book" });

